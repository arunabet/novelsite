<?php
// Template untuk menampilkan komentar dan reply secara rekursif
?>
<div class="comment-card" id="comment-<?= $comment['id'] ?>">
    <div class="card mb-2">
        <div class="card-body">
            <div class="d-flex">
                <div class="flex-shrink-0 me-3">
                    <?php if ($comment['avatar']): ?>
                    <img src="/uploads/avatars/<?= htmlspecialchars($comment['avatar']) ?>" 
                         class="rounded-circle" width="50" height="50" alt="Avatar">
                    <?php else: ?>
                    <div class="rounded-circle bg-secondary" style="width:50px;height:50px;"></div>
                    <?php endif; ?>
                </div>
                <div class="flex-grow-1">
                    <div class="d-flex justify-content-between">
                        <h6 class="mb-1"><?= htmlspecialchars($comment['username']) ?></h6>
                        <small class="text-muted">
                            <?= date('d M Y H:i', strtotime($comment['created_at'])) ?>
                        </small>
                    </div>
                    <p class="mb-2"><?= nl2br(htmlspecialchars($comment['content'])) ?></p>
                    
                    <div class="comment-actions">
                        <button class="btn btn-sm btn-outline-primary reply-btn" 
                                data-comment-id="<?= $comment['id'] ?>">
                            <i class="bi bi-reply"></i> Balas
                        </button>
                        <button class="btn btn-sm btn-outline-secondary mention-btn" 
                                data-username="<?= htmlspecialchars($comment['username']) ?>">
                            <i class="bi bi-at"></i> Mention
                        </button>
                    </div>
                    
                    <!-- Form Reply -->
                    <div class="reply-form mt-3" id="reply-form-<?= $comment['id'] ?>">
                        <form method="post">
                            <input type="hidden" name="chapter_id" value="<?= $current_chapter['id'] ?>">
                            <input type="hidden" name="parent_id" value="<?= $comment['id'] ?>">
                            <div class="mb-2">
                                <textarea class="form-control" name="content" rows="2" 
                                          placeholder="Balas @<?= htmlspecialchars($comment['username']) ?>..." required></textarea>
                            </div>
                            <button type="submit" name="comment" class="btn btn-primary btn-sm">
                                <i class="bi bi-send"></i> Kirim Balasan
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Replies -->
    <?php if (!empty($comment['replies'])): ?>
        <div class="replies">
            <?php foreach ($comment['replies'] as $reply): ?>
                <?php 
                // Rekursif untuk nested replies
                $temp = $comment;
                $comment = $reply;
                include __DIR__ . '/comment_template.php';
                $comment = $temp;
                ?>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>