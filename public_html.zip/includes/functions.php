<?php
require_once __DIR__ . '/../config/database.php';

// Fungsi untuk registrasi user
function registerUser($username, $email, $password) {
    global $pdo;
    
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, 'user')");
    return $stmt->execute([$username, $email, $hashed_password]);
}

// Fungsi untuk login
function login($emailOrUsername, $password) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? OR username = ?");
    $stmt->execute([$emailOrUsername, $emailOrUsername]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['avatar'] = $user['avatar'];
        return true;
    }
    return false;
}

// Fungsi untuk menambahkan cerita baru
function addStory($title, $synopsis, $cover = null, $author_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("INSERT INTO stories (title, synopsis, cover, author_id) VALUES (?, ?, ?, ?)");
    return $stmt->execute([$title, $synopsis, $cover, $author_id]);
}

// Fungsi untuk menambahkan bab baru
function addChapter($story_id, $title, $content, $order) {
    global $pdo;
    
    $stmt = $pdo->prepare("INSERT INTO chapters (story_id, title, content, chapter_order) VALUES (?, ?, ?, ?)");
    return $stmt->execute([$story_id, $title, $content, $order]);
}

// Fungsi untuk mendapatkan semua cerita
function getAllStories() {
    global $pdo;
    
    $stmt = $pdo->query("SELECT * FROM stories ORDER BY created_at DESC");
    return $stmt->fetchAll();
}

// Fungsi untuk mendapatkan detail cerita
function getStoryById($id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM stories WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function getChaptersByStoryId($story_id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM chapters WHERE story_id = ? ORDER BY chapter_order ASC");
    $stmt->execute([$story_id]);
    return $stmt->fetchAll();
}

function getChapterById($id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM chapters WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

// Fungsi untuk menambahkan komentar
function addComment($chapter_id, $user_id, $content) {
    global $pdo;
    
    $stmt = $pdo->prepare("INSERT INTO comments (chapter_id, user_id, content) VALUES (?, ?, ?)");
    return $stmt->execute([$chapter_id, $user_id, $content]);
}

// Fungsi untuk mendapatkan komentar
function getCommentsByChapter($chapter_id) {
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT c.*, u.username, u.avatar 
        FROM comments c 
        JOIN users u ON c.user_id = u.id 
        WHERE c.chapter_id = ? 
        ORDER BY c.created_at DESC
    ");
    $stmt->execute([$chapter_id]);
    return $stmt->fetchAll();
}

// Fungsi untuk menambahkan like
function addLike($story_id, $user_id) {
    global $pdo;
    
    // Cek apakah sudah ada like
    $stmt = $pdo->prepare("SELECT * FROM likes WHERE story_id = ? AND user_id = ?");
    $stmt->execute([$story_id, $user_id]);
    
    if ($stmt->rowCount() > 0) {
        // Jika sudah ada, hapus like
        $stmt = $pdo->prepare("DELETE FROM likes WHERE story_id = ? AND user_id = ?");
        return $stmt->execute([$story_id, $user_id]);
    } else {
        // Jika belum ada, tambahkan like
        $stmt = $pdo->prepare("INSERT INTO likes (story_id, user_id) VALUES (?, ?)");
        return $stmt->execute([$story_id, $user_id]);
    }
}

// Fungsi untuk mendapatkan jumlah like
function getLikeCount($story_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM likes WHERE story_id = ?");
    $stmt->execute([$story_id]);
    $result = $stmt->fetch();
    return $result['count'];
}

// Fungsi untuk mengecek apakah user sudah like
function hasLiked($story_id, $user_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT * FROM likes WHERE story_id = ? AND user_id = ?");
    $stmt->execute([$story_id, $user_id]);
    return $stmt->rowCount() > 0;
}

// Fungsi untuk reset password
function resetPassword($email, $new_password) {
    global $pdo;
    
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE email = ?");
    return $stmt->execute([$hashed_password, $email]);
}

// Fungsi untuk update profil
function updateProfile($user_id, $username, $email, $avatar = null) {
    global $pdo;
    
    if ($avatar) {
        $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, avatar = ? WHERE id = ?");
        return $stmt->execute([$username, $email, $avatar, $user_id]);
    } else {
        $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ? WHERE id = ?");
        return $stmt->execute([$username, $email, $user_id]);
    }
}

// Fungsi untuk update password
function updatePassword($user_id, $new_password) {
    global $pdo;
    
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
    return $stmt->execute([$hashed_password, $user_id]);
}
?>