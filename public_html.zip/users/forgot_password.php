<?php
session_start();
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    
    // Generate random password
    $new_password = bin2hex(random_bytes(8));
    
    if (resetPassword($email, $new_password)) {
        // Send email (ini hanya simulasi, di production gunakan library email seperti PHPMailer)
        $success = "Password baru telah dikirim ke email Anda: " . htmlspecialchars($new_password);
    } else {
        $error = "Email tidak ditemukan.";
    }
}
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <h2 class="mb-4">Lupa Password</h2>
        
        <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if (isset($success)): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
        <?php else: ?>
        <form method="post">
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <button type="submit" class="btn btn-primary">Reset Password</button>
        </form>
        <?php endif; ?>
        
        <div class="mt-3">
            <a href="/users/login.php">Kembali ke login</a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>