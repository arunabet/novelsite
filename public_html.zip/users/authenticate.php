<?php
session_start();
require_once __DIR__ . '/../config/database.php';

// Ambil data dari form
$emailOrUsername = trim($_POST['email_or_username'] ?? '');
$password = $_POST['password'] ?? '';

// Validasi
if (empty($emailOrUsername) || empty($password)) {
    header('Location: /users/login.php?error=invalid_credentials');
    exit;
}

// Cari user di database
$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? OR username = ?");
$stmt->execute([$emailOrUsername, $emailOrUsername]);
$user = $stmt->fetch();

// Verifikasi password
if ($user && password_verify($password, $user['password'])) {
    // Set session
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['email'] = $user['email'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['avatar'] = $user['avatar'];
    
    // Redirect ke halaman sebelumnya atau home
    $redirect_url = $_SESSION['redirect_url'] ?? '/';
    unset($_SESSION['redirect_url']);
    header("Location: $redirect_url");
    exit;
} else {
    header('Location: /users/login.php?error=invalid_credentials');
    exit;
}