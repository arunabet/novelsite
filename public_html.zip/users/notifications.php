<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: /users/login.php');
    exit;
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/functions.php';

// Tandai semua notifikasi sebagai dibaca saat halaman dibuka
markNotificationsAsRead($_SESSION['user_id']);

// Dapatkan semua notifikasi
$notifications = getUserNotifications($_SESSION['user_id'], 50);
?>

<div class="container mt-4">
    <h2 class="mb-4"><i class="bi bi-bell"></i> Notifikasi</h2>
    
    <div class="card">
        <div class="card-body">
            <?php if (!empty($notifications)): ?>
                <div class="list-group">
                    <?php foreach ($notifications as $notification): ?>
                    <a href="/stories/view.php?id=<?= $notification['story_id'] ?>&chapter=<?= $notification['chapter_id'] ?>#comment-<?= $notification['target_id'] ?>" 
                       class="list-group-item list-group-item-action">
                        <div class="d-flex align-items-center">
                            <div class="flex-shrink-0 me-3">
                                <?php if ($notification['sender_avatar']): ?>
                                <img src="/uploads/avatars/<?= htmlspecialchars($notification['sender_avatar']) ?>" 
                                     class="rounded-circle" width="50" height="50" alt="Avatar">
                                <?php else: ?>
                                <div class="rounded-circle bg-secondary" style="width:50px;height:50px;"></div>
                                <?php endif; ?>
                            </div>
                            <div class="flex-grow-1">
                                <div class="d-flex justify-content-between">
                                    <h6 class="mb-1"><?= htmlspecialchars($notification['sender_name']) ?></h6>
                                    <small class="text-muted"><?= date('d M Y H:i', strtotime($notification['created_at'])) ?></small>
                                </div>
                                <p class="mb-1">
                                    <?= $notification['type'] === 'reply' ? 'Membalas komentar Anda' : 'Menyukai komentar Anda' ?>
                                </p>
                                <small class="text-muted">
                                    <i class="bi bi-book"></i> <?= htmlspecialchars($notification['story_title']) ?> - 
                                    <i class="bi bi-bookmark"></i> <?= htmlspecialchars($notification['chapter_title']) ?>
                                </small>
                            </div>
                        </div>
                    </a>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="bi bi-bell-slash" style="font-size: 3rem; color: #6c757d;"></i>
                    <h5 class="mt-3">Tidak ada notifikasi</h5>
                    <p>Anda belum memiliki notifikasi saat ini</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>