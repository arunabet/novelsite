<?php
session_start();

// Jika sudah login, redirect ke home
if (isset($_SESSION['user_id'])) {
    header('Location: /');
    exit;
}

// Pesan error
$error = '';
if (isset($_GET['error'])) {
    $error = match($_GET['error']) {
        'invalid_credentials' => 'Email/username atau password salah',
        'login_required' => 'Silakan login untuk melanjutkan',
        default => ''
    };
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Yusufasabi</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .login-container {
            background-color: white;
            padding: 30px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }
        .login-title {
            text-align: center;
            margin-bottom: 20px;
            font-size: 24px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .login-button {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        .login-button:hover {
            background-color: #45a049;
        }
        .login-links {
            text-align: center;
            margin-top: 15px;
            font-size: 14px;
        }
        .login-links a {
            color: #4CAF50;
            text-decoration: none;
        }
        .login-links a:hover {
            text-decoration: underline;
        }
        .error-message {
            color: #f44336;
            text-align: center;
            margin-bottom: 15px;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            font-size: 12px;
            color: #777;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-title">Login</div>
        
        <?php if ($error): ?>
        <div class="error-message"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <form action="/users/authenticate.php" method="post">
            <div class="form-group">
                <label for="email_or_username">Email atau Username</label>
                <input type="text" id="email_or_username" name="email_or_username" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" class="login-button">Login</button>
        </form>
        
        <div class="login-links">
            <a href="/users/forgot_password.php">Lupa password?</a> | 
            <a href="/users/register.php">Buat akun baru</a>
        </div>
        
        <div class="footer">
            © 2025 Yusufasabi - Penulis amatir yang berbagi kisah hidup nggak penting
        </div>
    </div>
</body>
</html>