<?php
session_start();
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: /users/login.php');
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $bio = trim($_POST['bio']);
    
    // Handle avatar upload
    $avatar = null;
    if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = __DIR__ . '/../uploads/avatars/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $file_ext = pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION);
        $avatar = 'avatar_' . $_SESSION['user_id'] . '_' . time() . '.' . $file_ext;
        move_uploaded_file($_FILES['avatar']['tmp_name'], $upload_dir . $avatar);
        
        // Delete old avatar if exists
        if (!empty($_SESSION['avatar']) && file_exists($upload_dir . $_SESSION['avatar'])) {
            unlink($upload_dir . $_SESSION['avatar']);
        }
    }
    
    // Update profile
    global $pdo;
    if ($avatar) {
        $stmt = $pdo->prepare("UPDATE users SET username = ?, bio = ?, avatar = ? WHERE id = ?");
        $stmt->execute([$username, $bio, $avatar, $_SESSION['user_id']]);
        $_SESSION['avatar'] = $avatar;
    } else {
        $stmt = $pdo->prepare("UPDATE users SET username = ?, bio = ? WHERE id = ?");
        $stmt->execute([$username, $bio, $_SESSION['user_id']]);
    }
    
    $_SESSION['username'] = $username;
    $success = "Profil berhasil diperbarui!";
}

// Get current user data
global $pdo;
$stmt = $pdo->prepare("SELECT username, bio, avatar FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();
?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">Profil Saya</h4>
                </div>
                <div class="card-body">
                    <?php if (isset($success)): ?>
                        <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
                    <?php endif; ?>
                    
                    <form method="post" enctype="multipart/form-data">
                        <div class="text-center mb-4">
                            <?php if (!empty($user['avatar'])): ?>
                                <img src="/uploads/avatars/<?php echo htmlspecialchars($user['avatar']); ?>" 
                                     class="rounded-circle" width="150" height="150" alt="Foto Profil">
                            <?php else: ?>
                                <div class="rounded-circle bg-secondary d-inline-block" 
                                     style="width: 150px; height: 150px;"></div>
                            <?php endif; ?>
                            <div class="mt-3">
                                <input type="file" class="form-control" id="avatar" name="avatar" accept="image/*">
                                <small class="text-muted">Ukuran maksimal 2MB (Format: JPG, PNG)</small>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="username" class="form-label">Nama</label>
                            <input type="text" class="form-control" id="username" name="username" 
                                   value="<?php echo htmlspecialchars($user['username']); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="bio" class="form-label">Bio</label>
                            <textarea class="form-control" id="bio" name="bio" rows="3" 
                                      placeholder="Ceritakan sedikit tentang Anda..."><?php echo htmlspecialchars($user['bio']); ?></textarea>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                            <a href="/" class="btn btn-outline-secondary">Kembali</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>