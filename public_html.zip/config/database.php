<?php
$host = 'localhost';
$dbname = 'u645523008_DByoushouldbe';
$username = 'u645523008_youshouldbe22';
$password = 'Makkudo13@';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>