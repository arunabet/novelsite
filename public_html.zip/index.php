<?php
session_start();
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/functions.php';
?>

<div class="row">
    <div class="col-md-8">
        <h2 class="mb-4">Cerita Terbaru</h2>
        <?php
        $stories = getAllStories();
        if (count($stories) > 0):
            foreach ($stories as $story):
        ?>
        <div class="card mb-4">
            <?php if ($story['cover']): ?>
            <img src="/uploads/covers/<?php echo htmlspecialchars($story['cover']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($story['title']); ?>">
            <?php endif; ?>
            <div class="card-body">
                <h3 class="card-title"><?php echo htmlspecialchars($story['title']); ?></h3>
                <p class="card-text"><?php echo htmlspecialchars($story['synopsis']); ?></p>
                <a href="/stories/view.php?id=<?php echo $story['id']; ?>" class="btn btn-primary">Baca Cerita</a>
                <span class="ms-3">
                    <i class="bi bi-heart<?php echo (isset($_SESSION['user_id']) && hasLiked($story['id'], $_SESSION['user_id'])) ? '-fill' : ''; ?> like-btn" data-story-id="<?php echo $story['id']; ?>" style="cursor: pointer;"></i>
                    <span class="like-count"><?php echo getLikeCount($story['id']); ?></span> Likes
                </span>
            </div>
        </div>
        <?php
            endforeach;
        else:
        ?>
        <div class="alert alert-info">Belum ada cerita yang tersedia.</div>
        <?php endif; ?>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Tentang Yusufasabi</h5>
                <p class="card-text">Seorang penulis amatir yang berbagi kisah hidup nggak penting.</p>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>