<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

session_start();

// Redirect jika belum login
if (!isset($_SESSION['user_id'])) {
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
    header('Location: /users/login.php?message=login_required');
    exit;
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/functions.php';

try {
    // Dapatkan semua cerita dari database
    $stmt = $pdo->query("
        SELECT s.*, COUNT(l.id) as like_count, 
               (SELECT COUNT(*) FROM chapters WHERE story_id = s.id) as chapter_count
        FROM stories s
        LEFT JOIN likes l ON s.id = l.story_id
        GROUP BY s.id
        ORDER BY s.created_at DESC
    ");
    $stories = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>

<div class="container mt-4">
    <h2 class="mb-4">Daftar Cerita</h2>
    
    <div class="row">
        <?php if (count($stories) > 0): ?>
            <?php foreach ($stories as $story): ?>
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <?php if ($story['cover']): ?>
                    <img src="/uploads/covers/<?= htmlspecialchars($story['cover']) ?>" 
                         class="card-img-top" 
                         alt="<?= htmlspecialchars($story['title']) ?>"
                         style="height: 200px; object-fit: cover;">
                    <?php endif; ?>
                    
                    <div class="card-body">
                        <h5 class="card-title"><?= htmlspecialchars($story['title']) ?></h5>
                        <p class="card-text text-muted">
                            <?= htmlspecialchars(substr($story['synopsis'], 0, 100)) ?><?= strlen($story['synopsis']) > 100 ? '...' : '' ?>
                        </p>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="badge bg-primary">
                                <?= $story['chapter_count'] ?> Bab
                            </span>
                            <span class="text-muted">
                                <i class="bi bi-heart-fill text-danger"></i> <?= $story['like_count'] ?>
                            </span>
                        </div>
                    </div>
                    <div class="card-footer bg-transparent">
                        <a href="/stories/view.php?id=<?= $story['id'] ?>" class="btn btn-sm btn-primary">Baca</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="alert alert-info">
                    Belum ada cerita yang tersedia.
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>