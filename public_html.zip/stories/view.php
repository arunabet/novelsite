<?php
session_start();

// Redirect jika belum login
if (!isset($_SESSION['user_id'])) {
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
    header('Location: /users/login.php?message=login_required');
    exit;
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/functions.php';

// Validasi parameter ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: /stories/');
    exit;
}

$story_id = (int)$_GET['id'];
$story = getStoryById($story_id);

// Validasi cerita ada
if (!$story) {
    header('Location: /stories/');
    exit;
}

// Dapatkan bab-bab cerita
$chapters = getChaptersByStoryId($story_id);

// Handle like
if (isset($_POST['like']) && isset($_SESSION['user_id'])) {
    addLike($story_id, $_SESSION['user_id']);
    header("Location: /stories/view.php?id=$story_id");
    exit;
}

// Handle comment
if (isset($_POST['comment']) && isset($_SESSION['user_id'])) {
    $chapter_id = (int)$_POST['chapter_id'];
    $content = trim($_POST['content']);
    
    if (!empty($content)) {
        addComment($chapter_id, $_SESSION['user_id'], $content);
        header("Location: /stories/view.php?id=$story_id&chapter=$chapter_id#comments");
        exit;
    }
}

// Tentukan bab yang aktif
$current_chapter = null;
if (isset($_GET['chapter'])) {
    $current_chapter = getChapterById((int)$_GET['chapter']);
} elseif (!empty($chapters)) {
    $current_chapter = $chapters[0];
}

// Dapatkan komentar untuk bab aktif
$comments = [];
if ($current_chapter) {
    $comments = getCommentsByChapter($current_chapter['id']);
}

// Fungsi untuk mendapatkan story_id dari chapter_id
function getStoryIdByChapterId($chapter_id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT story_id FROM chapters WHERE id = ?");
    $stmt->execute([$chapter_id]);
    return $stmt->fetchColumn();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($story['title']) ?> - Yusufasabi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Segoe UI', Roboto, 'Helvetica Neue', sans-serif;
            background-color: #f8f9fa;
            color: #495057;
        }
        .story-header {
            border-bottom: 1px solid #dee2e6;
            padding-bottom: 1rem;
            margin-bottom: 2rem;
        }
        .chapter-content {
            font-size: 1.1rem;
            line-height: 1.8;
            color: #212529;
        }
        .like-btn {
            transition: all 0.3s ease;
        }
        .like-btn:hover {
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    <!-- Navigasi -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="/">Yusufasabi</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="/users/profile.php">
                                <i class="bi bi-person-circle"></i> Profil
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/users/logout.php">
                                <i class="bi bi-box-arrow-right"></i> Logout
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="/users/login.php">
                                <i class="bi bi-box-arrow-in-right"></i> Login
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Konten Utama -->
    <div class="container my-4">
        <div class="row">
            <div class="col-lg-8">
                <!-- Header Cerita -->
                <div class="story-header">
                    <?php if ($story['cover']): ?>
                    <img src="/uploads/covers/<?= htmlspecialchars($story['cover']) ?>" 
                         class="img-fluid rounded mb-3" 
                         alt="<?= htmlspecialchars($story['title']) ?>">
                    <?php endif; ?>
                    
                    <h1><?= htmlspecialchars($story['title']) ?></h1>
                    <p class="lead"><?= nl2br(htmlspecialchars($story['synopsis'])) ?></p>
                    
                    <form method="post" class="d-inline-block mb-3">
                        <button type="submit" name="like" class="btn btn-outline-danger like-btn">
                            <i class="bi bi-heart<?= hasLiked($story_id, $_SESSION['user_id']) ? '-fill' : '' ?>"></i>
                            <span class="like-count"><?= getLikeCount($story_id) ?></span>
                        </button>
                    </form>
                </div>

                <!-- Konten Bab -->
                <?php if ($current_chapter): ?>
                <article class="chapter-content mb-5">
                    <h2><?= htmlspecialchars($current_chapter['title']) ?></h2>
                    <?= nl2br(htmlspecialchars($current_chapter['content'])) ?>
                </article>

                <!-- Navigasi Bab -->
                <div class="d-flex justify-content-between mb-5">
                    <?php 
                    $prev_chapter = null;
                    $next_chapter = null;
                    
                    foreach ($chapters as $index => $chapter) {
                        if ($chapter['id'] == $current_chapter['id']) {
                            if ($index > 0) $prev_chapter = $chapters[$index - 1];
                            if ($index < count($chapters) - 1) $next_chapter = $chapters[$index + 1];
                            break;
                        }
                    }
                    ?>
                    
                    <?php if ($prev_chapter): ?>
                    <a href="/stories/view.php?id=<?= $story_id ?>&chapter=<?= $prev_chapter['id'] ?>" class="btn btn-primary">
                        <i class="bi bi-chevron-left"></i> Bab Sebelumnya
                    </a>
                    <?php else: ?>
                    <span></span>
                    <?php endif; ?>
                    
                    <?php if ($next_chapter): ?>
                    <a href="/stories/view.php?id=<?= $story_id ?>&chapter=<?= $next_chapter['id'] ?>" class="btn btn-primary">
                        Bab Selanjutnya <i class="bi bi-chevron-right"></i>
                    </a>
                    <?php else: ?>
                    <span></span>
                    <?php endif; ?>
                </div>
                <?php else: ?>
                <div class="alert alert-warning">
                    Cerita ini belum memiliki bab.
                </div>
                <?php endif; ?>

                <!-- Komentar -->
                <section id="comments" class="mb-5">
                    <h3><i class="bi bi-chat-left-text"></i> Komentar</h3>
                    
                    <?php if (isset($_SESSION['user_id']) && $current_chapter): ?>
                    <form method="post" class="mb-4">
                        <input type="hidden" name="chapter_id" value="<?= $current_chapter['id'] ?>">
                        <div class="mb-3">
                            <textarea class="form-control" name="content" rows="3" placeholder="Tulis komentar Anda..." required></textarea>
                        </div>
                        <button type="submit" name="comment" class="btn btn-primary">Kirim Komentar</button>
                    </form>
                    <?php elseif (!isset($_SESSION['user_id'])): ?>
                    <div class="alert alert-info">
                        <a href="/users/login.php" class="alert-link">Login</a> untuk meninggalkan komentar.
                    </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($comments)): ?>
                        <?php foreach ($comments as $comment): ?>
                        <div class="card mb-3">
                            <div class="card-body">
                                <div class="d-flex">
                                    <div class="flex-shrink-0 me-3">
                                        <?php if ($comment['avatar']): ?>
                                        <img src="/uploads/avatars/<?= htmlspecialchars($comment['avatar']) ?>" 
                                             class="rounded-circle" width="50" height="50" alt="Avatar">
                                        <?php else: ?>
                                        <div class="rounded-circle bg-secondary" style="width:50px;height:50px;"></div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h6 class="mt-0 mb-1"><?= htmlspecialchars($comment['username']) ?></h6>
                                        <small class="text-muted"><?= date('d M Y H:i', strtotime($comment['created_at'])) ?></small>
                                        <p class="mt-2 mb-0"><?= nl2br(htmlspecialchars($comment['content'])) ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="alert alert-secondary">Belum ada komentar.</div>
                    <?php endif; ?>
                </section>
            </div>
            
            <!-- Daftar Bab -->
            <div class="col-lg-4">
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        Daftar Bab
                    </div>
                    <div class="list-group list-group-flush">
                        <?php if (!empty($chapters)): ?>
                            <?php foreach ($chapters as $chapter): ?>
                            <a href="/stories/view.php?id=<?= $story_id ?>&chapter=<?= $chapter['id'] ?>" 
                               class="list-group-item list-group-item-action <?= ($current_chapter && $current_chapter['id'] == $chapter['id']) ? 'active' : '' ?>">
                                <?= htmlspecialchars($chapter['title']) ?>
                            </a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="list-group-item">Belum ada bab</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php require_once __DIR__ . '/../includes/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Smooth scroll to comments
        if (window.location.hash === '#comments') {
            document.querySelector('#comments').scrollIntoView({ 
                behavior: 'smooth' 
            });
        }
    </script>
</body>
</html>