<?php
session_start();
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: /users/login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $chapter_id = $_POST['chapter_id'];
    $user_id = $_SESSION['user_id'];
    $content = trim($_POST['content']);
    
    if (!empty($content)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO comments (chapter_id, user_id, content) VALUES (?, ?, ?)");
            $stmt->execute([$chapter_id, $user_id, $content]);
            
            // Redirect kembali ke halaman chapter
            header("Location: /stories/view.php?id=" . getStoryIdByChapter($chapter_id) . "&chapter=" . $chapter_id . "#comments");
            exit;
        } catch (PDOException $e) {
            die("Error adding comment: " . $e->getMessage());
        }
    }
}

// Fungsi bantu untuk mendapatkan story_id dari chapter
function getStoryIdByChapter($chapter_id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT story_id FROM chapters WHERE id = ?");
    $stmt->execute([$chapter_id]);
    return $stmt->fetchColumn();
}