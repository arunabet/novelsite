<?php
session_start();
require_once __DIR__ . '/../../../includes/header.php';
require_once __DIR__ . '/../../../includes/functions.php';

// Check if user is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: /users/login.php');
    exit;
}

if (!isset($_GET['story_id'])) {
    header('Location: /admin/stories/manage.php');
    exit;
}

$story_id = $_GET['story_id'];
$story = getStoryById($story_id);

if (!$story) {
    header('Location: /admin/stories/manage.php');
    exit;
}

// Get the next chapter order
$stmt = $pdo->prepare("SELECT MAX(chapter_order) FROM chapters WHERE story_id = ?");
$stmt->execute([$story_id]);
$max_order = $stmt->fetchColumn();
$next_order = $max_order ? $max_order + 1 : 1;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    $order = (int)$_POST['order'];
    
    if (addChapter($story_id, $title, $content, $order)) {
        $_SESSION['success'] = "Bab berhasil ditambahkan.";
        header("Location: /admin/stories/chapters/add.php?story_id=$story_id");
        exit;
    } else {
        $error = "Gagal menambahkan bab.";
    }
}
?>

<div class="container mt-4">
    <h2 class="mb-4">Tambah Bab Baru untuk "<?php echo htmlspecialchars($story['title']); ?>"</h2>
    
    <?php if (isset($error)): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['success'])): ?>
    <div class="alert alert-success"><?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    
    <form method="post">
        <div class="mb-3">
            <label for="title" class="form-label">Judul Bab</label>
            <input type="text" class="form-control" id="title" name="title" required>
        </div>
        <div class="mb-3">
            <label for="order" class="form-label">Urutan Bab</label>
            <input type="number" class="form-control" id="order" name="order" value="<?php echo $next_order; ?>" min="1" required>
        </div>
        <div class="mb-3">
            <label for="content" class="form-label">Isi Bab</label>
            <textarea class="form-control" id="content" name="content" rows="10" required></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
        <a href="/admin/stories/chapters/manage.php?story_id=<?php echo $story_id; ?>" class="btn btn-secondary">Batal</a>
    </form>
</div>

<?php require_once __DIR__ . '/../../../includes/footer.php'; ?>