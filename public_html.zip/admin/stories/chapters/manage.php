<?php
session_start();
require_once __DIR__ . '/../../../includes/header.php';
require_once __DIR__ . '/../../../includes/functions.php';

// Check if user is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: /users/login.php');
    exit;
}

if (!isset($_GET['story_id'])) {
    header('Location: /admin/stories/manage.php');
    exit;
}

$story_id = $_GET['story_id'];
$story = getStoryById($story_id);

if (!$story) {
    header('Location: /admin/stories/manage.php');
    exit;
}

// Handle chapter deletion
if (isset($_GET['delete'])) {
    $chapter_id = $_GET['delete'];
    
    $stmt = $pdo->prepare("DELETE FROM chapters WHERE id = ?");
    if ($stmt->execute([$chapter_id])) {
        $_SESSION['success'] = "Bab berhasil dihapus.";
    } else {
        $_SESSION['error'] = "Gagal menghapus bab.";
    }
    
    header("Location: /admin/stories/chapters/manage.php?story_id=$story_id");
    exit;
}

$chapters = getChaptersByStoryId($story_id);
?>

<div class="container mt-4">
    <h2 class="mb-4">Kelola Bab untuk "<?php echo htmlspecialchars($story['title']); ?>"</h2>
    
    <?php if (isset($_SESSION['success'])): ?>
    <div class="alert alert-success"><?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>
    
    <div class="mb-3">
        <a href="/admin/stories/chapters/add.php?story_id=<?php echo $story_id; ?>" class="btn btn-primary">Tambah Bab Baru</a>
        <a href="/admin/stories/manage.php" class="btn btn-secondary">Kembali ke Daftar Cerita</a>
    </div>
    
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Judul Bab</th>
                    <th>Tanggal Dibuat</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($chapters) > 0): ?>
                    <?php foreach ($chapters as $chapter): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($chapter['chapter_order']); ?></td>
                        <td><?php echo htmlspecialchars($chapter['title']); ?></td>
                        <td><?php echo date('d M Y', strtotime($chapter['created_at'])); ?></td>
                        <td>
                            <a href="/admin/stories/chapters/edit.php?id=<?php echo $chapter['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                            <a href="/admin/stories/chapters/manage.php?story_id=<?php echo $story_id; ?>&delete=<?php echo $chapter['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus bab ini?')">Hapus</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4" class="text-center">Belum ada bab untuk cerita ini.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../../../includes/footer.php'; ?>