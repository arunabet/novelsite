<?php
session_start();
require_once __DIR__ . '/../../../includes/header.php';
require_once __DIR__ . '/../../../includes/functions.php';

// Check if user is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: /users/login.php');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: /admin/stories/manage.php');
    exit;
}

$chapter_id = $_GET['id'];
$chapter = getChapterById($chapter_id);

if (!$chapter) {
    header('Location: /admin/stories/manage.php');
    exit;
}

$story = getStoryById($chapter['story_id']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    $order = (int)$_POST['order'];
    
    $stmt = $pdo->prepare("UPDATE chapters SET title = ?, content = ?, chapter_order = ? WHERE id = ?");
    if ($stmt->execute([$title, $content, $order, $chapter_id])) {
        $_SESSION['success'] = "Bab berhasil diperbarui.";
        header("Location: /admin/stories/chapters/edit.php?id=$chapter_id");
        exit;
    } else {
        $error = "Gagal memperbarui bab.";
    }
}
?>

<div class="container mt-4">
    <h2 class="mb-4">Edit Bab dari "<?php echo htmlspecialchars($story['title']); ?>"</h2>
    
    <?php if (isset($error)): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['success'])): ?>
    <div class="alert alert-success"><?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    
    <form method="post">
        <div class="mb-3">
            <label for="title" class="form-label">Judul Bab</label>
            <input type="text" class="form-control" id="title" name="title" value="<?php echo htmlspecialchars($chapter['title']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="order" class="form-label">Urutan Bab</label>
            <input type="number" class="form-control" id="order" name="order" value="<?php echo htmlspecialchars($chapter['chapter_order']); ?>" min="1" required>
        </div>
        <div class="mb-3">
            <label for="content" class="form-label">Isi Bab</label>
            <textarea class="form-control" id="content" name="content" rows="10" required><?php echo htmlspecialchars($chapter['content']); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        <a href="/admin/stories/chapters/manage.php?story_id=<?php echo $story['id']; ?>" class="btn btn-secondary">Batal</a>
    </form>
</div>

<?php require_once __DIR__ . '/../../../includes/footer.php'; ?>