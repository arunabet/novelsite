<?php
// Aktifkan error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Definisikan root path
define('ROOT_PATH', '/home/u645523008/domains/yusufasabi.com/public_html');

// Cek dan include file database
require_once ROOT_PATH . '/config/database.php';

// Mulai session dan cek admin
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ' . ROOT_PATH . '/users/login.php');
    exit;
}

// Proses form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $synopsis = trim($_POST['synopsis']);
    $author_id = $_SESSION['user_id'];
    
    // Handle cover upload
    $cover = null;
    if (isset($_FILES['cover']) && $_FILES['cover']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = ROOT_PATH . '/uploads/covers/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $file_ext = pathinfo($_FILES['cover']['name'], PATHINFO_EXTENSION);
        $cover = 'cover_' . time() . '.' . $file_ext;
        move_uploaded_file($_FILES['cover']['tmp_name'], $upload_dir . $cover);
    }
    
    // Tambahkan cerita ke database
    try {
        $stmt = $pdo->prepare("INSERT INTO stories (title, synopsis, cover, author_id) VALUES (?, ?, ?, ?)");
        $stmt->execute([$title, $synopsis, $cover, $author_id]);
        
        $story_id = $pdo->lastInsertId();
        $_SESSION['success'] = "Cerita berhasil ditambahkan!";
        header("Location: " . ROOT_PATH . "/admin/stories/chapters/add.php?story_id=" . $story_id);
        exit;
    } catch (PDOException $e) {
        $error = "Gagal menambahkan cerita: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Cerita Baru - Yusufasabi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .form-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="/admin/dashboard.php">Admin Panel</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="/admin/dashboard.php">Kembali ke Situs</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container my-5">
        <div class="form-container">
            <h2 class="mb-4">Tambah Cerita Baru</h2>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            
            <form method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="title" class="form-label">Judul Cerita</label>
                    <input type="text" class="form-control" id="title" name="title" required>
                </div>
                
                <div class="mb-3">
                    <label for="synopsis" class="form-label">Sinopsis</label>
                    <textarea class="form-control" id="synopsis" name="synopsis" rows="5" required></textarea>
                </div>
                
                <div class="mb-3">
                    <label for="cover" class="form-label">Cover Cerita (Opsional)</label>
                    <input type="file" class="form-control" id="cover" name="cover" accept="image/*">
                    <small class="text-muted">Format: JPG, PNG. Ukuran maksimal 2MB.</small>
                </div>
                
                <div class="d-flex justify-content-between">
                    <a href="/admin/stories/manage.php" class="btn btn-secondary">Batal</a>
                    <button type="submit" class="btn btn-primary">Simpan Cerita</button>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>