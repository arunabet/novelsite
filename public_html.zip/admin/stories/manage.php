<?php
session_start();
require_once __DIR__ . '/../../config/database.php';

// Cek admin login
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: /users/login.php');
    exit;
}

// Handle delete request
if (isset($_GET['delete'])) {
    $story_id = (int)$_GET['delete'];
    
    try {
        $pdo->beginTransaction();
        
        // 1. Hapus semua komentar terkait cerita ini
        $pdo->prepare("DELETE comments FROM comments 
                      JOIN chapters ON comments.chapter_id = chapters.id 
                      WHERE chapters.story_id = ?")
           ->execute([$story_id]);
        
        // 2. Hapus semua chapter
        $pdo->prepare("DELETE FROM chapters WHERE story_id = ?")
           ->execute([$story_id]);
        
        // 3. Hapus cover file jika ada
        $stmt = $pdo->prepare("SELECT cover FROM stories WHERE id = ?");
        $stmt->execute([$story_id]);
        $cover = $stmt->fetchColumn();
        
        if ($cover && file_exists(__DIR__ . '/../../uploads/covers/' . $cover)) {
            unlink(__DIR__ . '/../../uploads/covers/' . $cover);
        }
        
        // 4. Hapus cerita
        $pdo->prepare("DELETE FROM stories WHERE id = ?")
           ->execute([$story_id]);
        
        $pdo->commit();
        
        $_SESSION['success'] = "Cerita berhasil dihapus!";
    } catch (PDOException $e) {
        $pdo->rollBack();
        $_SESSION['error'] = "Gagal menghapus cerita: " . $e->getMessage();
    }
    
    header("Location: /admin/stories/manage.php");
    exit;
}

// Ambil daftar cerita
$stmt = $pdo->query("
    SELECT s.*, COUNT(c.id) as chapter_count 
    FROM stories s
    LEFT JOIN chapters c ON s.id = c.story_id
    GROUP BY s.id
    ORDER BY s.created_at DESC
");
$stories = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Cerita - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h2>Kelola Cerita</h2>
        
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success"><?= $_SESSION['success'] ?></div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger"><?= $_SESSION['error'] ?></div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>
        
        <a href="/admin/dashboard.php" class="btn btn-secondary mb-3">Kembali ke Dashboard</a>
        <a href="/admin/stories/add.php" class="btn btn-primary mb-3">Tambah Cerita Baru</a>
        
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Judul</th>
                    <th>Bab</th>
                    <th>Tanggal Dibuat</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($stories) > 0): ?>
                    <?php foreach ($stories as $story): ?>
                    <tr>
                        <td><?= htmlspecialchars($story['title']) ?></td>
                        <td><?= $story['chapter_count'] ?></td>
                        <td><?= date('d M Y', strtotime($story['created_at'])) ?></td>
                        <td>
                            <a href="/admin/stories/edit.php?id=<?= $story['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                            <a href="/admin/stories/chapters/manage.php?story_id=<?= $story['id'] ?>" class="btn btn-sm btn-info">Kelola Bab</a>
                            <a href="/admin/stories/manage.php?delete=<?= $story['id'] ?>" 
                               class="btn btn-sm btn-danger" 
                               onclick="return confirm('Apakah Anda yakin ingin menghapus cerita ini? Semua bab dan komentar terkait juga akan dihapus.')">
                               Hapus
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4" class="text-center">Belum ada cerita.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>