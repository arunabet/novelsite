<?php
session_start();
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/functions.php';

// Check if user is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: /users/login.php');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: /admin/stories/manage.php');
    exit;
}

$story_id = $_GET['id'];
$story = getStoryById($story_id);

if (!$story) {
    header('Location: /admin/stories/manage.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $synopsis = trim($_POST['synopsis']);
    
    // Handle cover upload
    $cover = $story['cover'];
    if (isset($_FILES['cover']) && $_FILES['cover']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = __DIR__ . '/../../uploads/covers/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        // Delete old cover if exists
        if ($cover && file_exists($upload_dir . $cover)) {
            unlink($upload_dir . $cover);
        }
        
        $file_ext = pathinfo($_FILES['cover']['name'], PATHINFO_EXTENSION);
        $cover = 'cover_' . time() . '.' . $file_ext;
        move_uploaded_file($_FILES['cover']['tmp_name'], $upload_dir . $cover);
    }
    
    // Handle cover removal
    if (isset($_POST['remove_cover']) && $_POST['remove_cover'] === '1') {
        if ($cover && file_exists(__DIR__ . '/../../uploads/covers/' . $cover)) {
            unlink(__DIR__ . '/../../uploads/covers/' . $cover);
        }
        $cover = null;
    }
    
    $stmt = $pdo->prepare("UPDATE stories SET title = ?, synopsis = ?, cover = ? WHERE id = ?");
    if ($stmt->execute([$title, $synopsis, $cover, $story_id])) {
        $_SESSION['success'] = "Cerita berhasil diperbarui.";
        header("Location: /admin/stories/edit.php?id=$story_id");
        exit;
    } else {
        $error = "Gagal memperbarui cerita.";
    }
}
?>

<div class="container mt-4">
    <h2 class="mb-4">Edit Cerita</h2>
    
    <?php if (isset($error)): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['success'])): ?>
    <div class="alert alert-success"><?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    
    <form method="post" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="title" class="form-label">Judul Cerita</label>
            <input type="text" class="form-control" id="title" name="title" value="<?php echo htmlspecialchars($story['title']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="synopsis" class="form-label">Sinopsis</label>
            <textarea class="form-control" id="synopsis" name="synopsis" rows="5" required><?php echo htmlspecialchars($story['synopsis']); ?></textarea>
        </div>
        <div class="mb-3">
            <label for="cover" class="form-label">Cover</label>
            <?php if ($story['cover']): ?>
            <div class="mb-2">
                <img src="/uploads/covers/<?php echo htmlspecialchars($story['cover']); ?>" class="img-thumbnail" style="max-height: 200px;">
                <div class="form-check mt-2">
                    <input class="form-check-input" type="checkbox" id="remove_cover" name="remove_cover" value="1">
                    <label class="form-check-label" for="remove_cover">Hapus cover</label>
                </div>
            </div>
            <?php endif; ?>
            <input type="file" class="form-control" id="cover" name="cover" accept="image/*">
        </div>
        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        <a href="/admin/stories/manage.php" class="btn btn-secondary">Batal</a>
    </form>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>