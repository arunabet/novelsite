<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: /users/login.php');
    exit;
}

require_once __DIR__ . '/../../config/database.php';

// Handle comment deletion
if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM comments WHERE id = ?")->execute([$_GET['delete']]);
    header("Location: /admin/comments/manage.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Komentar - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h2>Kelola Komentar</h2>
        <a href="/admin/dashboard.php" class="btn btn-secondary mb-3">Kembali ke Dashboard</a>
        
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Pengguna</th>
                    <th>Komentar</th>
                    <th>Tanggal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $stmt = $pdo->query("
                    SELECT c.*, u.username 
                    FROM comments c 
                    JOIN users u ON c.user_id = u.id 
                    ORDER BY c.created_at DESC
                ");
                while ($comment = $stmt->fetch()):
                ?>
                <tr>
                    <td><?= htmlspecialchars($comment['username']) ?></td>
                    <td><?= htmlspecialchars(substr($comment['content'], 0, 50)) ?>...</td>
                    <td><?= date('d M Y', strtotime($comment['created_at'])) ?></td>
                    <td>
                        <a href="?delete=<?= $comment['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Hapus komentar ini?')">Hapus</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>