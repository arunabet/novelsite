<?php
// Aktifkan error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Definisikan root path
define('ROOT_PATH', '/home/u645523008/domains/yusufasabi.com/public_html');

// Cek dan include file database
$db_config = ROOT_PATH . '/config/database.php';
if (!file_exists($db_config)) {
    die("Database configuration missing. Please contact administrator.");
}
require_once $db_config;

// Mulai session dan cek admin
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ' . ROOT_PATH . '/users/login.php');
    exit;
}

// Ambil data statistik
try {
    $stories_count = $pdo->query("SELECT COUNT(*) FROM stories")->fetchColumn();
    $chapters_count = $pdo->query("SELECT COUNT(*) FROM chapters")->fetchColumn();
    $users_count = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $comments_count = $pdo->query("SELECT COUNT(*) FROM comments")->fetchColumn();
} catch (PDOException $e) {
    die("Error fetching statistics: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Yusufasabi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .stat-card {
            transition: all 0.3s ease;
            border-radius: 10px;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        .admin-nav {
            background-color: #343a40;
            padding: 15px 0;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark admin-nav">
        <div class="container">
            <a class="navbar-brand" href="https://yusufasabi.com/">Yusufasabi Admin</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="https://yusufasabi.com/">Lihat Situs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/users/logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <h2 class="mb-4">Dashboard Admin</h2>
        
        <!-- Statistik -->
        <div class="row mb-4">
            <div class="col-md-3 mb-3">
                <div class="card stat-card text-white bg-primary">
                    <div class="card-body">
                        <h5 class="card-title">Total Cerita</h5>
                        <h1 class="display-4"><?= $stories_count ?></h1>
                        <a href="/admin/stories/manage.php" class="text-white">Kelola Cerita</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="card stat-card text-white bg-success">
                    <div class="card-body">
                        <h5 class="card-title">Total Bab</h5>
                        <h1 class="display-4"><?= $chapters_count ?></h1>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="card stat-card text-white bg-info">
                    <div class="card-body">
                        <h5 class="card-title">Total Pengguna</h5>
                        <h1 class="display-4"><?= $users_count ?></h1>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 mb-3">
                <div class="card stat-card text-white bg-warning">
                    <div class="card-body">
                        <h5 class="card-title">Total Komentar</h5>
                        <h1 class="display-4"><?= $comments_count ?></h1>
                        <a href="/admin/comments/manage.php" class="text-white">Kelola Komentar</a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Quick Actions -->
<div class="card">
    <div class="card-body">
        <h5 class="card-title">Aksi Cepat</h5>
        <div class="d-flex gap-2">
            <a href="/admin/stories/add.php" class="btn btn-primary">Tambah Cerita Baru</a>
            <a href="/admin/stories/manage.php" class="btn btn-secondary">Kelola Semua Cerita</a>
            <a href="/admin/comments/manage.php" class="btn btn-info">Kelola Komentar</a>
        </div>
    </div>
</div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>